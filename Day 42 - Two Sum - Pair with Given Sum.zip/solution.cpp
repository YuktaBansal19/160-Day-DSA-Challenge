// Day 42: Two Sum - Pair with Given Sum
#include <iostream>
#include <unordered_set>
#include <vector>
using namespace std;

bool hasPairWithSum(const vector<int>& nums, int target) {
    unordered_set<int> seen;
    for (int num : nums) {
        if (seen.count(target - num)) return true;
        seen.insert(num);
    }
    return false;
}

int main() {
    vector<int> arr = {2, 7, 11, 15};
    int target = 9;

    if (hasPairWithSum(arr, target))
        cout << "Pair with sum " << target << " exists." << endl;
    else
        cout << "No pair with sum " << target << " found." << endl;

    return 0;
}
