# Day 42: Two Sum - Pair with Given Sum

## Problem Statement
Given an array of integers and a target value, determine if there are any two integers in the array whose sum is equal to the given target.

## Example
**Input:** arr = [2, 7, 11, 15], target = 9  
**Output:** True (Because 2 + 7 = 9)

## Approach
- Use a hash set to store elements seen so far.
- For each element `num`, check if `target - num` is in the set.
- If yes, return true.
- If no pair is found, return false.

## Time Complexity
O(n) — One pass through the array

## Space Complexity
O(n) — For the hash set
