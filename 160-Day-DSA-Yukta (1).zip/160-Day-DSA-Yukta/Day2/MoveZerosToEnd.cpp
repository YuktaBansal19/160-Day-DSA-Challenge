// Problem: Move All Zeros to End
// Link: https://leetcode.com/problems/move-zeroes/
// Time Complexity: O(n)
// Author: Yukta Bansal

#include <iostream>
#include <vector>
using namespace std;

void moveZeroes(vector<int>& nums) {
    int index = 0;
    for (int num : nums)
        if (num != 0) nums[index++] = num;
    while (index < nums.size())
        nums[index++] = 0;
}

int main() {
    vector<int> arr = {0, 1, 0, 3, 12};
    moveZeroes(arr);
    for (int num : arr) cout << num << " ";
    return 0;
}
