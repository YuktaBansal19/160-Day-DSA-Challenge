// Problem: Reverse an Array
// Link: https://www.geeksforgeeks.org/write-a-program-to-reverse-an-array-or-string/
// Time Complexity: O(n)
// Author: Yukta Bansal

#include <iostream>
#include <vector>
using namespace std;

void reverseArray(vector<int>& arr) {
    int left = 0, right = arr.size() - 1;
    while (left < right) swap(arr[left++], arr[right--]);
}

int main() {
    vector<int> arr = {1, 2, 3, 4, 5};
    reverseArray(arr);
    for (int num : arr) cout << num << " ";
    return 0;
}
